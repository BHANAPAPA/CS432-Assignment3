# config.py

MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'  # Change this to your MySQL username
MYSQL_PASSWORD = '1234'  # Change this to your MySQL password
MYSQL_DB = 'studentdb'
